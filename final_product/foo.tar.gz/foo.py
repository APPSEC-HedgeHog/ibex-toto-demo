print('Here is some code')
bad
